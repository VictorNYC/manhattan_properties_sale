/*
(Like df.head( ) on Python) 
*/
SELECT * FROM nymanhattan.active;

# check the total of my rows (like df.shape on Python)
SELECT count(*) FROM nymanhattan.active;
# 6201 is my row number (15 columns, 6201 rows)

/* 
I did not change the column names on my xlsm or csv file, SQL required backticks ` `
when column names have spaces or special characters.

- Alter table: specifies the table I want to modify.
- Rename column: renames the column.
*/
ALTER TABLE nymanhattan.active
RENAME COLUMN `Address` TO address,
RENAME COLUMN `Unit` TO unit_number,
RENAME COLUMN `Asking Price` TO asking_price,
RENAME COLUMN `Days on Market` TO days_on_market,
RENAME COLUMN `CS date` TO contract_signed_date,
RENAME COLUMN `Sub-Nbhood` TO neighborhood,
RENAME COLUMN `Property Type` TO property_type,
RENAME COLUMN `Beds` TO unit_type,
RENAME COLUMN `Bath` TO bath,
RENAME COLUMN `Size` TO size,
RENAME COLUMN `Price per SFT` TO price_sft,
RENAME COLUMN `Total Monthlies` TO total_monthlies,
RENAME COLUMN `Maint/CC` TO maintenance_cc,
RENAME COLUMN `RE Taxes` TO property_tax,
RENAME COLUMN `Url` TO url;
/* 
Backticks: are technically not required for the new column names,
if they don’t contain special characters, spaces and aren’t reserved keywords 
*/

# verify column names after renaming
SHOW COLUMNS FROM nymanhattan.active;

# Handling Nulls, empty strings or default values

# Searching for null values ​​in each column
SELECT 
    COUNT(CASE WHEN address IS NULL THEN 1 END) AS null_count_address,
    COUNT(CASE WHEN unit_number IS NULL THEN 1 END) AS null_count_unit_number,
    COUNT(CASE WHEN asking_price IS NULL THEN 1 END) AS null_count_asking_price,
    COUNT(CASE WHEN days_on_market IS NULL THEN 1 END) AS null_count_days_on_market,
    COUNT(CASE WHEN contract_signed_date IS NULL THEN 1 END) AS null_count_contract_signed_date,
    COUNT(CASE WHEN property_type IS NULL THEN 1 END) AS null_count_property_type,
    COUNT(CASE WHEN neighborhood IS NULL THEN 1 END) AS null_count_neighborhood,
    COUNT(CASE WHEN unit_type IS NULL THEN 1 END) AS null_count_unit_type,
    COUNT(CASE WHEN bath IS NULL THEN 1 END) AS null_count_bath,
    COUNT(CASE WHEN size IS NULL THEN 1 END) AS null_count_size,
    COUNT(CASE WHEN price_sft IS NULL THEN 1 END) AS null_count_price_sft,
    COUNT(CASE WHEN total_monthlies IS NULL THEN 1 END) AS null_count_total_monthlies,
    COUNT(CASE WHEN maintenance_cc IS NULL THEN 1 END) AS null_count_maintenance_cc,
    COUNT(CASE WHEN property_tax IS NULL THEN 1 END) AS null_count_property_tax,
    COUNT(CASE WHEN url IS NULL THEN 1 END) AS null_count_url
FROM nymanhattan.active;
# No nulls on columns, 

/* 
If the output of the query above was that there were not 0 Nulls, but I still need to check
for empty cells on the dataframe, empty cells might be empty strings (''), which are
different from NULL, also I still need to check for default values that often indicate
that the field was either NOT PROVIDED, or explicitly SET TO A DEFAULT value during 
*/

# check for EMPTY strings
SELECT
    COUNT(CASE WHEN total_monthlies = '' THEN 1 END) AS empty_count_total_monthlies,
    COUNT(CASE WHEN maintenance_cc = '' THEN 1 END) AS empty_count_maintenance_cc,
    COUNT(CASE WHEN property_tax = '' THEN 1 END) AS empty_count_property_tax
FROM nymanhattan.active;
/* 
The output of EMPTY strings is: 162 for total monthlies, 162 for maintenance, and 1019
for tax.
*/

# now, check for DEFAULT values
SELECT
    COUNT(CASE WHEN total_monthlies = 0 THEN 1 END) AS zero_count_total_monthlies,
    COUNT(CASE WHEN maintenance_cc = 0 THEN 1 END) AS zero_count_maintenance_cc,
    COUNT(CASE WHEN property_tax = 0 THEN 1 END) AS zero_count_property_tax
FROM nymanhattan.active;
/* 
The output of DEFAULT values is: 166 for total monthlies, 389 for maintenance, and 2839
for tax. 

- Number here are higher, suggesting that many of these columns have default numeric values
(like 0), rather than being empty strings.

- Considering industry context, many of the listings might not have a maintenance fee or
they do not have a common charge fee, rather than an omission of insertion of data, indeed,
they could be 0 value. 

- These columns total monthlies, maintenance and tax are not important for my analysis,
and I can drop the columns 
*/

# I will check EMPTY str or DEFAULT values for columns I need for my Data Analysis.
SELECT
    COUNT(CASE WHEN days_on_market = '' THEN 1 END) AS empty_count_days_on_market,
    COUNT(CASE WHEN property_type = '' THEN 1 END) AS empty_count_property_type,
    COUNT(CASE WHEN neighborhood = '' THEN 1 END) AS empty_count_neighborhood,
	COUNT(CASE WHEN unit_type = '' THEN 1 END) AS empty_count_unit_type
FROM nymanhattan.active;
/* 
Outputs
- neighborhood column: 2 empty values (I can check the address or unit_number to find out
the neighborhood).

- unit type column: 629 empty values. Knowing industry context, because this is unit type
column, this means that 0 value, means zero bedrooms, which means we are talking about a
Studio.
e.g. value 1 means 1 bedroom, value 2 means 2 bedroom.

- Solution for unit type column, I would like to map the data type from numerical data
(0,1,2,3), to categorical data and map (mapping, like in Python) to:
0 to Studio,
1 to 1 BR,
2 to 2 BR, 
3 to BR, and 
4 and greater to 4 BR+
(4BR+ is the standard for Real Estate)
*/

# now, check for DEFAULT values
SELECT
    COUNT(CASE WHEN days_on_market = 0 THEN 1 END) AS zero_count_days_on_market,
    COUNT(CASE WHEN property_type = 0 THEN 1 END) AS zero_count_property_type,
    COUNT(CASE WHEN neighborhood = 0 THEN 1 END) AS zero_count_neighborhood,
	COUNT(CASE WHEN unit_type = 0 THEN 1 END) AS zero_count_unit_type
FROM nymanhattan.active;
/*
Outputs:
- property type column: 6201 DEFAULT values (All the rows), (Null was 0),
- neighborhood column: 6201 DEFAULT values (All the rows), (Null was 0),
- unit type column: 629 DEFAULT values (Same row number than in EMPTY),
Is this a mistake? no, probably because I querying with 0, and this columns
are object type or categorical data, 0 is for numerical data.
*/

# Like df['column'].value_counts() in Python
SELECT property_type, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY property_type
ORDER BY value_count DESC;
# output: No nulls

# Now for neighborhood
SELECT neighborhood, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY neighborhood
ORDER BY value_count DESC;
# Output: 2 nulls on neighborhood column

/*
I want to check if I can find out the neighborhood by checking address
and unit number columns.
*/
SELECT a.address, a.unit_number, b.neighborhood
FROM nymanhattan.active a
JOIN nymanhattan.active b
ON a.address = b.address
AND a.unit_number = b.unit_number
WHERE a.neighborhood IS NULL OR a.neighborhood = ''
AND b.neighborhood IS NOT NULL AND b.neighborhood <> '';
/*
output is that there no columns with same address and unit number but with
neighborhood not null. 
*/

# I want to check the address and unit number on Google Maps to find out neighborhood
SELECT a.address, a.unit_number, 
       (SELECT neighborhood
        FROM nymanhattan.active b
        WHERE a.address = b.address
        AND a.unit_number = b.unit_number
        AND b.neighborhood IS NOT NULL AND b.neighborhood <> ''
        GROUP BY b.neighborhood
        ORDER BY COUNT(*) DESC
        LIMIT 3) AS guessed_neighborhood
FROM nymanhattan.active a
WHERE a.neighborhood IS NULL OR a.neighborhood = '';
/*
outputs:
329 GRAND SREET, HOUSE
180 SECOND AVENUE, HOUSE

- After searching on Google Maps, the first address is Lower East Side
- The second addres is on East Village

Uunit number says HOUSE, but that's not a problem.
*/

# disable safe update mode
SET SQL_SAFE_UPDATES = 0;

# filling null
UPDATE nymanhattan.active
SET neighborhood = 'Lower East Side'
WHERE address = '329 GRAND STREET' AND neighborhood IS NULL;

# filling null
UPDATE nymanhattan.active
SET neighborhood = 'East Village'
WHERE address = '180 SECOND AVENUE' AND neighborhood IS NULL;

# checking for nulls again on neighborhood column
SELECT neighborhood, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY neighborhood
ORDER BY value_count DESC;
# output: still 2 nulls

SELECT address, neighborhood
FROM nymanhattan.active
WHERE address IN ('329 GRAND STREET', '180 SECOND AVENUE');

# Check for Trailing Spaces
SELECT address, neighborhood
FROM nymanhattan.active
WHERE TRIM(address) IN ('329 GRAND STREET', '180 SECOND AVENUE');

SELECT address, HEX(address) AS hex_representation
FROM nymanhattan.active
WHERE address IN ('329 GRAND STREET', '180 SECOND AVENUE');

SELECT address, neighborhood
FROM nymanhattan.active
WHERE address IN ('329 GRAND STREET', '180 SECOND AVENUE') AND (neighborhood IS NULL OR neighborhood = '');

/*
I remember that at the beginning there were 0 nulls, this might be an empty string
*/
UPDATE nymanhattan.active
SET neighborhood = 'Lower East Side'
WHERE address = '329 GRAND STREET' 
  AND (neighborhood IS NULL OR neighborhood = '');
  
UPDATE nymanhattan.active
SET neighborhood = 'East Village'
WHERE address = '180 SECOND AVENUE' 
  AND (neighborhood IS NULL OR neighborhood = '');

# checking again for empty spaces
SELECT neighborhood, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY neighborhood
ORDER BY value_count DESC;
# output: no more empty spaces in neighborhood column!

/*
Drop rows where neighborhood is Roosevelt Island,
I do not need RI neighborhood for my data analysis.
*/
DELETE FROM nymanhattan.active
WHERE neighborhood = 'Roosevelt Island';

/*
There are rows that are not necessary for the data analysis. The order in which columns 
are dropped does not matter. Dropping columns will permanently delete the data stored in
those columns. Columns I will drop are:
- asking_price: analysis is not focused on prices, because this price change at the closing date, e.g due to discounts
(Keeping price_sft);
- contract_signed_date: there's no contracts signed on active listings;
- bath: analysis is not focused on bathrooms;
- size: analysis is not focused on size;
- price_sft: analysis is not focused on size, also because price is asking, NOT closing price;
(Keeping price_sft)
- total_monthlies: data not acurate due to asking prices Vs closing price;
- maintenance_cc: analysis is not focus on this;
- property_tax; this is not an analysis on taxes;
- url; we do not need the url's.
total columns to remove: 7


Originally, I removed the asking sale price per square foot column. Why? Because the asking sale price
at this early stage can be misleading to me, as the first sale price is not the closing price,
when clients sign contracts or close deals, or accept offers.

But Serhant's director asked me what the average sale price is right now on active listings
and per square foot. So, I reused my code again and kept those two columns so I could answer the director.
*/
ALTER TABLE nymanhattan.active
DROP COLUMN contract_signed_date,
DROP COLUMN bath,
DROP COLUMN size,
DROP COLUMN total_monthlies,
DROP COLUMN maintenance_cc,
DROP COLUMN property_tax,
DROP COLUMN url;

SELECT * FROM nymanhattan.active;
/*
ouput: now 8 columns and 6177 rows. I have less rows because I deleted rows
with Rosevelt Island on neighborhood column.
*/

/*
Checking value count on property type column
to verify if I can drop some rows here
*/
SELECT property_type, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY property_type
ORDER BY value_count DESC;
/* 
I have 7 values on property_type column. Vaues are: CONDO, COOP, TOWNHOUSE, 
CONDOP, RENTAL, COMMERCIAL and MIXED USE. 
- CONDO 3120
- COOP 2581
- TOWNHOUSE 309
- CONDOP 116
- RENTAL 41
- COMMERCIAL 8
- MIXED USE 2

As I mentioned on my past 2 Real Estate projects (Posted on Linkedin and Github), 
based on industry context on Manhattan, and advised for a Director at Serhant.
I will only keep the values of CONDO, COOP, TOWNHOUSE, CONDOP, and I will remoove
the rows with RENTAL, COMMERCIAL and MIXED USE. 

Total 51 rows to remove.
*/

/*
Code to reuse to only delete 1 value if needed:
DELETE FROM nymanhattan.active
WHERE property_type = 'RENTAL';
*/

# To remove more than 1 value in the column
DELETE FROM nymanhattan.active
WHERE property_type IN ('RENTAL', 'COMMERCIAL', 'MIXED USE');
# output: 51 rows affected (dropped)

# Now I need to check this on unit_type column
SELECT unit_type, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY unit_type
ORDER BY value_count DESC;
/*
On this output, there are units type that range from 0 to 24, skipping 14, 16, 17, 18,
19, 21, 22 and 23, which is irrelevant that there not a sequence, these are only the
number of bedrooms that unit has, in the case of the number 0 this is for Studios.
I will map this column.
*/

# Before mapping unit_type column, I will check for duplicates on my entire dataset.

# checking duplicates
SELECT address, unit_number, COUNT(*) AS count
FROM nymanhattan.active
GROUP BY address, unit_number
HAVING COUNT(*) > 1;
# output is that there's no duplicates listings on my entire dataset

/*
Mapping unit_type column
first, add a new column to store the categorical values
*/
ALTER TABLE nymanhattan.active
ADD COLUMN unit_type_categorical VARCHAR(50);

/*
Update the new column with mapped values
Use UPDATE statement with CASE
*/
UPDATE nymanhattan.active
SET unit_type_categorical = CASE 
    WHEN unit_type = 0 THEN 'Studio'
    WHEN unit_type = 1 THEN '1 BR'
    WHEN unit_type = 2 THEN '2 BR'
    WHEN unit_type = 3 THEN '3 BR'
    ELSE '4 BR+'  -- Handles values 4 and above or any other values not explicitly mapped
END;
# 6126 rows were affected (modified)

# checking the value counts on my new categorical column
SELECT unit_type_categorical, COUNT(*) AS value_count
FROM nymanhattan.active
GROUP BY unit_type_categorical
ORDER BY value_count DESC;
/* 
Nice!
Studio : 622 values
1BR : 1716
2 BR : 1778
3 BR : 1054
4 BR+ : 956
Why am I mapping? 
Because is best practice for my visualizations this representation, than 
having a 0, where people do not will not that 0 means Studio, also a bar chart
will not have values of more than 5 bedrooms because it will be overcrowded and
many of this units with high number of bedrooms do not have many counts to be
drastic and visually attractive on a chart. Also, a Director from Serhant advised me
that 4 BR+ is the standard when a unit has more than 4 bedrooms.
*/

/*
Keeping the unit_type numerical column for now, maybe is useful to create
percentages later with this numerical values, rather than categorical
*/

# like a df.head(5) in Python. To see how my new dataset looks on columns/rows
SELECT * FROM nymanhattan.active LIMIT 5;
# Looks good!


/*
Advanced Statistical Analysis
Handling outliers

Common Methods to Detect Outliers: 
1. Z-Score Method; and
2. IQR (Interquartile Range) Method

Steps:
1. Calculate Mean and Standard Deviation; and
2. Find Outliers Using the Mean and Standard Deviation.

I will start calculating mean and std, and the outliers,
First, from one column, the days_on_market.

I fact only one column is numeric, the old column of 
unit_type also is numerical, but my analysis needs to contain
all types of bedrooms/units.alter

Just checking days on market for practice
*/

# 1.Calculate Mean and Standard Deviation:
SELECT 
    AVG(days_on_market) AS mean_value,
    STDDEV(days_on_market) AS std_dev
FROM nymanhattan.active;
/*
Output for mean_value is 158.5317 (Days)
Output for std_dev is 191.5441 (Days)

And the median?
-- In MySQL, there isn’t a built-in MEDIAN function, 
so calculating the median requires a workaround.
*/

-- Calculate Z-scores and find outliers, with SUBQUERY
SELECT *,
       (days_on_market - sub.mean_value) / sub.std_dev AS z_score
FROM nymanhattan.active
JOIN (
    SELECT 
        AVG(days_on_market) AS mean_value,
        STDDEV(days_on_market) AS std_dev
    FROM nymanhattan.active
) AS sub
HAVING ABS(z_score) > 3
LIMIT 10000;
/*
output: 125 row(s) returned.

- 1. Z-Score calculation:

- Z-Score measures HOW MANY standard deviations a data point is from the mean.
- In practice, the Z-score for outliers is typically considered significant
if it’s GREATER than 3 or LESS than -3.

2. Key points:

- Limited Number of Outliers: The small number of rows (125) might indicate that
only a few data points significantly deviate from the mean, which is consistent
with statistical outlier detection.

- Data Distribution: If your data is tightly CLUSTERED AROUND THE MEAN, very few data
points will have Z-scores exceeding ±3. This can result in fewer outliers.
Query execution:

- My query correctly identifies outliers based on the Z-score. 
The LIMIT 10000 clause does not affect the number of rows returned
because there are only 125 rows that meet the outlier criteria.

Note: If I want to experiment with different thresholds for outliers if ±3
standard deviations seem too strict or too lenient. I could use ±2 or ±4
standard deviations to see how it affects the number of outliers.

Expected Behavior: If my data is normally distributed, the number of outliers
with a Z-score beyond ±3 is typically small, especially if the dataset is large.
*/

/*
# let's see how many rows SQL returns with a STD of 2
SELECT *,
       (days_on_market - sub.mean_value) / sub.std_dev AS z_score
FROM nymanhattan.active
JOIN (
    SELECT 
        AVG(days_on_market) AS mean_value,
        STDDEV(days_on_market) AS std_dev
    FROM nymanhattan.active
) AS sub
HAVING ABS(z_score) > 2  -- Adjusted threshold
LIMIT 10000;
# output: 248 rows returned
*/

/*
# let's see how many rows SQL returns with a STD of 4
SELECT *,
       (days_on_market - sub.mean_value) / sub.std_dev AS z_score
FROM nymanhattan.active
JOIN (
    SELECT 
        AVG(days_on_market) AS mean_value,
        STDDEV(days_on_market) AS std_dev
    FROM nymanhattan.active
) AS sub
HAVING ABS(z_score) > 4  -- Adjusted threshold
LIMIT 10000;
# output: 63 rows returned
*/

/*
Below you will see a lot of study notes, sorry for including them here. 
I do this because all my last projects this year have been in Python. 
So I am refreshing my muscle memory with SQL, which I haven't used in a long time.
*/

/*
STD DEV different Z-Score thresholds 3, 2 and 4, outputs:

- ±3 STD: returned 125 rows (suggests that these are moderate outliers).

- ±2 STD: returned 248 rows (threshold is less strict, this threshold is
more inclusive, capturing more data points as outliers), (are not extreme
but still deviating from the mean).

- ±4 STD: returned 63 rows (more lenient threshold, suggests that fewer
points are considered outliers, which is typical for more extreme outlier criteria).
(more exclusive), (It is useful for identifying only the most extreme outliers).

The results I obtained from experimenting with different Z-score thresholds
(±2, ±3, and ±4 standard deviations) reflect how sensitive the outlier detection is
based on the threshold I use.
*/

/*
Common Practices:

±3 STD: This is often used as a standard threshold for detecting outliers in many
statistical analyses. If I want a balance is good practice to use the ±3 standard
 deviations threshold 

And because this is a Data Analysis on Manhattan Active Listings, 3 STD DEV is perfect,
I think 2 STD DEV that capture more outliers could work for studies Healthcare and Medications,
because they also might want to be avoiding FALSE POSITIVES. Also 2 is to many data to delete
for this Real Estate project.
*/

/*
General Threshold Guidelines:

±2 This threshold often identifies around 5% of the data as outliers in a normal distribution. 

±3 This is a standard threshold for outliers in many statistical analyses, capturing data points
that fall in the outer 0.3% of a normal distribution. It is considered a balance between detecting
significant anomalies and avoiding false positives.

±4 This is a stricter threshold that typically identifies only the most extreme 0.006% of the data
 in a normal distribution. It is used when you want to focus on the most severe deviations.
*/



/*
Refreshing my muscle memory with SQL

What means this on the codes (Some of them I might not used it):
- INTO: in SQL, the INTO keyword is used to store the result of a query into variables.

- @ : the @ symbol denotes that these are variables, not columns or table names,
@ symbol is used to indicate a variable in MySQL. It’s like naming a box where you can store
and retrieve information.

- ABS : stands for "Absolute Value". It returns the absolute value of a number, which is the
number without its sign. In the context of the query, ABS(z_score) ensures you’re catching
outliers both ABOVE and BELOW the MEAN.

If the Z-score is 4 or -4, ABS(z_score) will be 4 in both cases (like on the screenshot I 
took from Youtube). Check if the Z-score is "far enough" from the mean, irrespective of direction.

*/

/*
output for z - score with threeshold of 3, 125 rows returned. I exported csv file 
with my 125 rows, and I checked the column of z score, and all of this properties
have a z score higher 3.
*/

# next step, delete 125 outliers on days on market column

/*
Delete outliers
*/
DELETE FROM nymanhattan.active
WHERE days_on_market IN (
    SELECT days_on_market
    FROM (
        SELECT 
            days_on_market,
            (days_on_market - sub.mean_value) / sub.std_dev AS z_score
        FROM nymanhattan.active
        JOIN (
            SELECT 
                AVG(days_on_market) AS mean_value,
                STDDEV(days_on_market) AS std_dev
            FROM nymanhattan.active
        ) AS sub
    ) AS subquery
    WHERE ABS(z_score) > 3
);
# output: 125 rows affected (dropped/removed)

/*
Code if I had an id column to reuse in the future if needed:
DELETE FROM nymanhattan.active
WHERE id IN (
    SELECT id
    FROM (
        SELECT 
            id,
            (days_on_market - sub.mean_value) / sub.std_dev AS z_score
        FROM nymanhattan.active
        JOIN (
            SELECT 
                AVG(days_on_market) AS mean_value,
                STDDEV(days_on_market) AS std_dev
            FROM nymanhattan.active
        ) AS sub
        HAVING ABS(z_score) > 3
    ) AS subquery
);
*/

SELECT * FROM nymanhattan.active;
# output: now 6001 rows returned
# 7 columns

/*

Self notes to refresh my muscle memory with SQL, I like
knowing every detail of the code and its meaning.

On the code above to delete outliers:

sub: this is an alias for a derived table or subquery, usage
of sub acts like a temporary table containing the results of
the subquery. It’s a way to use aggregated results (mean and
standard deviation) within the main query without needing
to re-calculate them.

/ sub.std_dev: Dividing by the standard deviation normalizes
this difference. By dividing by the standard deviation, I
am converting the difference into a Z-score, which tells me
how many standard deviations away a value is from the mean.
This helps in identifying outliers because extreme values
will have large Z-scores.

- summary:
sub: this is a temporary name for the results of a SUBQUERY
that calculates the mean and standard deviation. It helps
you refer to these calculations later in your query.

Division (/): the division is part of the Z-score formula.
It helps you understand HOW FAR each VALUE is from the MEAN,
in terms of standard deviations. This is crucial for detecting
outliers.

*/

# Data is clean

/*

SUMMARY OF MY PROCESS

Summary of my data cleaning and exploration work, so far: 
1. Changed my column names because they had symbols, spaces, etc.;
2. Handled null values, also handled empty values ​​and default values;
3. Created an index column (also primary key);
4. Removed the Roosevelt Island neighborhood;
5. Removed columns that were not needed for data analyses, for example 
like URL or contact signing date;
6. Removed 3 values ​​in the property type column;
7. Checked for duplicates;
8. Used feature engineering, created a column for unit_type with new values;
9. Calculated the mean and standard deviation on my days on market numeric data
column, then I calculated the z-score, with a threshold of 3, and removed outliers;
10. The next step is to reset the index.

After the data cleaning process, the data is clean and ready for analysis.

*/

# checking data types
DESCRIBE nymanhattan.active;
# I have text, integer and varchar(50) data types

SELECT * FROM nymanhattan.active;

/*
I exported the clean data on a new CSV, to make visualizations on Tableau to see Real Estate Insigths,

I did not do a reset index.
*/

Thank you! 

Data Analytics
by Victor Cornejo Leyva





/*
Extension of the project, to know average asking price per unit type and per sft, 
by request of Serhant's Director.
*/

/*
I want to know the average asking price by neighborhood
*/
SELECT AVG(asking_price),
           neighborhood
FROM nymanhattan.active
GROUP BY neighborhood
ORDER BY AVG(asking_price) DESC;
/*
Soho has the highest average price, with an avg price of 6,715,386 USD
followed by Midtown Center and TriBeCa.
The bottom 5 lowest average prices are in Upper Manhattan.
Lowest avg price is 470,115 USD
*/

/*
I want to know the average asking price by unit type categorical
*/
SELECT AVG(asking_price),
	   unit_type_categorical
FROM nymanhattan.active
GROUP BY unit_type_categorical
ORDER BY AVG(asking_price) DESC;
/*
Not surprising, 4 BR+ has the highest average price of 10,827,535 USD
The lowest average price is a Studio, avg price 660,005 USD
*/


# first to see median by asking price (without group by)
WITH RankedPrices AS (
    SELECT
        asking_price,
        ROW_NUMBER() OVER (ORDER BY asking_price) AS RowAsc,
        COUNT(*) OVER () AS TotalCount
    FROM nymanhattan.active
),
MedianValues AS (
    SELECT
        asking_price
    FROM RankedPrices
    WHERE RowAsc = (TotalCount + 1) / 2
       OR (TotalCount % 2 = 0 AND RowAsc IN (TotalCount / 2, TotalCount / 2 + 1))
)
SELECT
    asking_price AS median_asking_price
FROM MedianValues
ORDER BY median_asking_price DESC;
# output of 1,675,000 USD


# to know the median of asking price by neighborhood
WITH RankedPrices AS (
    SELECT
        asking_price,
        neighborhood,
        ROW_NUMBER() OVER (PARTITION BY neighborhood ORDER BY asking_price) AS RowAsc, # Assigns a row number in ascending order of asking prices within each neighborhood
        COUNT(*) OVER (PARTITION BY neighborhood) AS TotalCount # Counts the total number of rows within each neighborhood.
    FROM nymanhattan.active
),
MedianValues AS (
    SELECT
        neighborhood,
        asking_price
    FROM RankedPrices
    WHERE RowAsc = (TotalCount + 1) / 2
       OR (TotalCount % 2 = 0 AND RowAsc IN (TotalCount / 2, TotalCount / 2 + 1))
)
SELECT
    neighborhood,
    asking_price AS median_asking_price
FROM MedianValues
ORDER BY median_asking_price DESC;
/*
the highest median asking price is 5,500,000 USD and is located on SoHo.
the lowest median asking price is 409,000 USD and is located in West Harlem

Note: I have around 7 neighborhoods duplicated, the duplication is likely due
to the handling of neighborhoods with an even number of entries.
*/


# to know the median of asking price by unit type categorical
WITH RankedPrices AS (
    SELECT
        asking_price,
        unit_type_categorical,
        ROW_NUMBER() OVER (PARTITION BY unit_type_categorical ORDER BY asking_price) AS RowAsc,
        COUNT(*) OVER (PARTITION BY unit_type_categorical) AS TotalCount
    FROM nymanhattan.active
),
MedianValues AS (
    SELECT
        unit_type_categorical,
        asking_price
    FROM RankedPrices
    WHERE RowAsc = (TotalCount + 1) / 2
       OR (TotalCount % 2 = 0 AND RowAsc IN (TotalCount / 2, TotalCount / 2 + 1))
)
SELECT
    unit_type_categorical,
    asking_price AS median_asking_price
FROM MedianValues
ORDER BY median_asking_price DESC;
/*
Output: median values are 

- Studio $545,000 USD
- 1 BR $875,000 USD
- 2 BR $1,825,000 USD
- 3 BR $3,595,000 USD
- 4 BR+ $7,495,000 USD

There are duplicates on 1 BR and 3 BR, I explained that for neighborhoods and here,
the duplication is likely due to the handling of unit_type_categorical with an even
number of entries.
*/

# Note: did not remove outliers for asking price, asking price is not the closing price. 

/*
Continuing here. I was working on Tableau but a median price per sft of $7k dollars on Upper West Side did not
make sense, so I will drop outliers on asking price and price sft columns, I will use z - score 3
*/

# first to check how many we have, on price sft column
SELECT *,
       (price_sft - sub.mean_value) / sub.std_dev AS z_score
FROM nymanhattan.active
JOIN (
    SELECT 
        AVG(price_sft) AS mean_value,
        STDDEV(price_sft) AS std_dev
    FROM nymanhattan.active
) AS sub
HAVING ABS(z_score) > 3
LIMIT 10000;
/*
2 outliers and make sense with my visual on Tableau, these 2 outliers are on my row where UWS and Kips Bay are
neighborhoods, exactly where my mistake was on Tabluea!
kips bay price sft 399,900
UWS price sft 1,299,000
*/

# now to delete
DELETE FROM nymanhattan.active
WHERE price_sft IN (
    SELECT price_sft
    FROM (
        SELECT 
            price_sft,
            (price_sft - sub.mean_value) / sub.std_dev AS z_score
        FROM nymanhattan.active
        JOIN (
            SELECT 
                AVG(price_sft) AS mean_value,
                STDDEV(price_sft) AS std_dev
            FROM nymanhattan.active
        ) AS sub
    ) AS subquery
    WHERE ABS(z_score) > 3
);
# output: 2 rows affected.

# not let's take a look to asking price column
SELECT *,
       (asking_price - sub.mean_value) / sub.std_dev AS z_score
FROM nymanhattan.active
JOIN (
    SELECT 
        AVG(asking_price) AS mean_value,
        STDDEV(asking_price) AS std_dev
    FROM nymanhattan.active
) AS sub
HAVING ABS(z_score) > 3
LIMIT 10000;
/*
output: this number of outliers is more significant, it is 90 outliers, but the market
on nyc is expensive. Also, a z score of 3 is the standard. I will drop this 90 rows
*/

# now to delete (asking price)
DELETE FROM nymanhattan.active
WHERE asking_price IN (
    SELECT asking_price
    FROM (
        SELECT 
            asking_price,
            (asking_price - sub.mean_value) / sub.std_dev AS z_score
        FROM nymanhattan.active
        JOIN (
            SELECT 
                AVG(asking_price) AS mean_value,
                STDDEV(asking_price) AS std_dev
            FROM nymanhattan.active
        ) AS sub
    ) AS subquery
    WHERE ABS(z_score) > 3
);
# output: 90 rows affected.

# with 92 rows affected total, I will export a new CSV to work on Tabluea. 09/18/2024
SELECT * FROM nymanhattan.active;
# before 6002 rows, now 5779 rows.alter
# Thanks!